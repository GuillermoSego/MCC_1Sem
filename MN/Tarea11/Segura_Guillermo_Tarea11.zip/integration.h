
double nc_open_0(double a, double b, double (*f)(double));
double nc_open_1(double a, double b, double (*f)(double));
double nc_open_2(double a, double b, double (*f)(double));
double nc_open_3(double a, double b, double (*f)(double));
double nc_closed_1(double a, double b, double (*f)(double));
double nc_closed_2(double a, double b, double (*f)(double));
double nc_closed_3(double a, double b, double (*f)(double));
double nc_closed_4(double a, double b, double (*f)(double));
double changeOfInterval(double x, double a, double b);
double gauss_quad_1(double a, double b, double (*f)(double));
double gauss_quad_2(double a, double b, double (*f)(double));
double gauss_quad_3(double a, double b, double (*f)(double));
double gauss_quad_4(double a, double b, double (*f)(double));
double gauss_quad_5(double a, double b, double (*f)(double));